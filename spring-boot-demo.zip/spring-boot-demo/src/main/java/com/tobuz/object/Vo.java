package com.tobuz.object;

import java.util.List;

public class Vo {
    private List<String[]> data;

    public List<String[]> getData() {
        return data;
    }

    public void setData(List<String[]> data) {
        this.data = data;
    }
}