package com.tobuz.object;

public class BusinessListingFeatureInfoDTO {

	BusinessListingDTO businessListingDTO;
	
	BusinessFeatureDTO businessFeatureDTO ;

	public BusinessListingDTO getBusinessListingDTO() {
		return businessListingDTO;
	}

	public void setBusinessListingDTO(BusinessListingDTO businessListingDTO) {
		this.businessListingDTO = businessListingDTO;
	}

	public BusinessFeatureDTO getBusinessFeatureDTO() {
		return businessFeatureDTO;
	}

	public void setBusinessFeatureDTO(BusinessFeatureDTO businessFeatureDTO) {
		this.businessFeatureDTO = businessFeatureDTO;
	}
	
	
}
