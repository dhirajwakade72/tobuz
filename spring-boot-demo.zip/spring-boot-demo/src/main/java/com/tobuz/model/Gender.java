package com.tobuz.model;

public final  class Gender {

	public static String MALE = "MALE";
	public static String FEMALE = "FEMALE";
	;
}
