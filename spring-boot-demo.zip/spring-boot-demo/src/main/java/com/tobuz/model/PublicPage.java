package com.tobuz.model;

public enum PublicPage {
	

	BUSINESS_FOR_SALE,

	COMMERCIAL_FOR_SALE,

	BUYERS_INVESTORS,
	

	BROKERS,
	
	
	BUSINESS_SERVICES,
	
	DISTRESS_SALES;

}
