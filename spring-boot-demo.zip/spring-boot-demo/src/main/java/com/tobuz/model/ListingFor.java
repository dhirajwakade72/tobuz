package com.tobuz.model;

public final class  ListingFor {
		

public final static	String SALE  = "SALE";

public final static	String RENT_OR_LEASE  = "RENT_OR_LEASE";

public final static	String OTHERS  = "OTHERS";
	
}
