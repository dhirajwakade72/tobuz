package com.tobuz.model;

public final class ListingSalePriceType {
	
	
	private String SALE_PRICE = "SALE_PRICE";
	
	private String AVAILABLE_ON_APPROACH = "AVAILABLE_ON_APPROACH";
	
	
}
