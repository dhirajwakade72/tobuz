package com.tobuz.model;



public enum PaymentStatus {
	

	INITIATED,
	

	SUCCESS,
	

	CANCELLED,
	

	DECLINED;
	
}
