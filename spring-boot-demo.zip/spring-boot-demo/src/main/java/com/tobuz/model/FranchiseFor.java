package com.tobuz.model;

public enum FranchiseFor {
	
	SALE,
	RESALE;

}
