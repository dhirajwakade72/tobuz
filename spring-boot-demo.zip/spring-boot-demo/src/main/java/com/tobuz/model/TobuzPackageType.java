package com.tobuz.model;

import java.util.LinkedList;
import java.util.List;


public class TobuzPackageType {

	public static String FREE ;

	public static String SILVER;

	public static String GOLD ; 

	public static String BRONZE; 

	public static String PREMIUM ;

	public static String REGISTER ;
	
	/*
	 * public static List<TobuzPackageType> getBuyerPackages(){
	 * List<TobuzPackageType> packages = new LinkedList<TobuzPackageType>();
	 * for(TobuzPackageType packageType : TobuzPackageType.values()) {
	 * if(!packageType.equals(TobuzPackageType.BRONZE)) { packages.add(packageType);
	 * } } return packages; }
	 */

	/*
	 * public String capitalize(){ return
	 * WordUtils.capitalizeFully(toString().replaceAll("_", " ")); }
	 */
}
