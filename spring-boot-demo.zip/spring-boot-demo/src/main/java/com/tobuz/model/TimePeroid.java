package com.tobuz.model;

public final class TimePeroid {
	
	
	private static String ANNUAL = "ANNUAL";

	private static String MONTH = "MONTH";
	

	private static String WEEK = "WEEK";
	

}
