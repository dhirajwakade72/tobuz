package com.tobuz.model;

public enum ListingAdvertLable {
	
	NEW,
	
	
	FEATURED,
	

	HOT_ITEM;
	
	
}
