package com.tobuz.model;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


public final class ListingType {
	
public final static	String BUSINESS  = "BUSINESS";

public final static	String FRANCHISE  = "FRANCHISE";


public final static	String COMMERCIAL  = "COMMERCIAL";
	
	
}
