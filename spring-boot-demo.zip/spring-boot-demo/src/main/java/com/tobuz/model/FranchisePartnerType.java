package com.tobuz.model;

public enum FranchisePartnerType {
	

	MASTER,

	RESALE,
	

	UNIT;
	
	/*
	 * public String capitalize(){ return
	 * WordUtils.capitalizeFully(toString().replaceAll("_", " ")); }
	 */

}
