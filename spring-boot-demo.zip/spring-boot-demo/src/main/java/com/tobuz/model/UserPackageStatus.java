package com.tobuz.model;



public enum UserPackageStatus {

	ACTIVE,

	EXPIRED;
	
}
