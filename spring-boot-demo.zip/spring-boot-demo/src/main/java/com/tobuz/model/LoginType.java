package com.tobuz.model;


public final class  LoginType {
	

	private static String TOBUZ = "TOBUZ" ;
	 
	private static String FACEBOOK = "FACEBOOK" ;
	
	private static String GOOGLE = "GOOGLE" ;

	private static String LINKED_IN = "LINKED_IN" ;

	private static String TWITTER = "TWITTER" ;
	

	/*
	 * public String capitalize(){ return
	 * WordUtils.capitalizeFully(toString().replaceAll("_", " ")); }
	 */

}
